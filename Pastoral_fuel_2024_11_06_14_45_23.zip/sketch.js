let bommen = [];
let achtergrondKleur = [255, 255, 255]; // Beginachtergrondkleur (brug afbeelding)
let brug;
let appelRoodImg, appelGroenImg, bomAfbeelding;
let raster;
let eve, alice, bob, appelRood, appelGroen;

let oranjeRij = 5; // De rij die oranje is
let oranjeKolom = 7; // De kolom die oranje is

function preload() {
  brug = loadImage("images/backgrounds/dame_op_brug_1800.jpg"); // De afbeelding van het meisje op de brug
  appelRoodImg = loadImage("images/sprites/Appel/appel_2.png");
  appelGroenImg = loadImage("images/sprites/Appel/appel_1.png");
  bomAfbeelding = loadImage("images/sprites/Bom/bom.png", 
      () => console.log("Bom afbeelding geladen"), 
      () => console.log("Fout bij het laden van de bom afbeelding"));
}

function setup() {
  canvas = createCanvas(900, 600);
  canvas.parent();
  frameRate(10);
  textFont("Verdana");
  
  raster = new Raster(12, 18);
  raster.berekenCelGrootte();
  
  eve = new Jos();
  eve.stapGrootte = 1 * raster.celGrootte;
  for (let b = 0; b < 6; b++) {
    let frameEve = loadImage("images/sprites/Eve100px/Eve_" + b + ".png");
    eve.animatie.push(frameEve);
  }
  
  alice = new Vijand(700, 200);
  alice.stapGrootte = 1 * eve.stapGrootte;
  alice.sprite = loadImage("images/sprites/Alice100px/Alice.png");

  bob = new Vijand(600, 400);
  bob.stapGrootte = 1 * eve.stapGrootte;
  bob.sprite = loadImage("images/sprites/Bob100px/Bob.png");  

  appelRood = new StilAppel(300, 300);
  appelGroen = new StuiterendeAppel(100, 100);

  // Plaats de bommen rechts van het midden in de oranje kolom en rij
  for (let i = 0; i < 5; i++) {
    let x = floor(random(oranjeKolom + 1, raster.aantalKolommen)) * raster.celGrootte;
    let y = floor(random(oranjeRij, oranjeRij + 1)) * raster.celGrootte;
    bommen.push(new Bom(x, y));
  }
}

function draw() {
  // Background veranderen afhankelijk van of de cursor boven de oranje cellen is
  if (isCursorOverOrangeCells()) {
    achtergrondKleur = [173, 216, 230]; // Lichtblauw als de cursor over oranje cellen is
  } else {
    achtergrondKleur = [255, 255, 255]; // Brug afbeelding als de cursor niet over oranje cellen is
  }

  background(achtergrondKleur); // De huidige achtergrondkleur wordt hier ingesteld
  
  raster.teken(oranjeRij, oranjeKolom); // Teken het raster met oranje rij en kolom
  
  for (let i = bommen.length - 1; i >= 0; i--) {
    let bom = bommen[i];
    bom.beweeg();
    bom.toon();
    
    if (eve.raaktBom(bom) && !bom.geraakt) {
      eve.leven--;
      bom.geraakt = true;
      bommen.splice(i, 1);
    }
  }

  eve.beweeg();
  alice.beweeg();
  bob.beweeg();
  eve.toon();
  alice.toon();
  bob.toon();

  if (eve.wordtGeraakt(alice) || eve.wordtGeraakt(bob)) {
    eve.leven--;
    if (eve.leven <= 0) {
      noLoop();
    }
  }

  appelRood.toon();
  appelGroen.beweeg();
  appelGroen.toon();

  if (eve.eetAppel(appelRood)) {}
  if (eve.eetAppel(appelGroen)) {}

  if (eve.gehaald) {
    background('green');
    fill('white');
    textSize(90);
    textAlign(CENTER, CENTER);
    text("Je hebt gewonnen!", width / 2, height / 2);
    noLoop();
  }

  if (eve.leven <= 0) {
    background('red');
    fill('white');
    textSize(100);
    textAlign(CENTER, CENTER);
    text("Je hebt verloren!", width / 2, height / 2);
    noLoop();
  } else {
    fill('black');
    textSize(20);
    text("Levens: " + eve.leven, 10, 30);
  }
}

// Functie om te controleren of de cursor boven de oranje cellen is
function isCursorOverOrangeCells() {
  let x = mouseX;
  let y = mouseY;
  
  // Controleer of de cursor over de oranje rij of kolom gaat
  let kolomIndex = floor(x / raster.celGrootte);
  let rijIndex = floor(y / raster.celGrootte);
  
  return (rijIndex === oranjeRij || kolomIndex === oranjeKolom);
}

// Raster class
class Raster {
  constructor(r, k) {
    this.aantalRijen = r;
    this.aantalKolommen = k;
    this.celGrootte = null;
  }
  
  berekenCelGrootte() {
    this.celGrootte = canvas.width / this.aantalKolommen;
  }
  
  teken(gekleurdeRij, gekleurdeKolom) {
    push();
    noFill();
    stroke('grey');
    
    for (let rij = 0; rij < this.aantalRijen; rij++) {
      for (let kolom = 0; kolom < this.aantalKolommen; kolom++) {
        // Controleer of dit de gekleurde rij of kolom is
        if (rij === gekleurdeRij || kolom === gekleurdeKolom) {
          fill('orange'); // Oranje voor de rij of kolom
          noStroke(); // Geen rand
        } else {
          noFill(); // Geen vulkleur voor de andere cellen
          stroke('grey'); // Grijze rand
        }
        rect(kolom * this.celGrootte, rij * this.celGrootte, this.celGrootte, this.celGrootte);
      }
    }
    pop();
  }
}

// Jos class (Eve)
class Jos {
  constructor() {
    this.x = 400;
    this.y = 300;
    this.animatie = [];
    this.frameNummer = 3;
    this.stapGrootte = null;
    this.gehaald = false;
    this.leven = 1;
  }
  
  beweeg() {
    if (keyIsDown(65)) {
      this.x -= this.stapGrootte;
      this.frameNummer = 2;
    }
    if (keyIsDown(68)) {
      this.x += this.stapGrootte;
      this.frameNummer = 1;
    }
    if (keyIsDown(87)) {
      this.y -= this.stapGrootte;
      this.frameNummer = 4;
    }
    if (keyIsDown(83)) {
      this.y += this.stapGrootte;
      this.frameNummer = 5;
    }
    
    this.x = constrain(this.x, 0, canvas.width);
    this.y = constrain(this.y, 0, canvas.height - raster.celGrootte);
    
    // Check if Jos has reached the far right side
    if (this.x >= canvas.width - raster.celGrootte) {
      this.gehaald = true;
    }
  }
  
  wordtGeraakt(vijand) {
    return this.x === vijand.x && this.y === vijand.y;
  }

  raaktBom(bom) {
    const afstand = dist(this.x, this.y, bom.x, bom.y);
    return afstand < raster.celGrootte;
  }
  
  eetAppel(appel) {
    const afstand = dist(this.x, this.y, appel.x, appel.y);
    if (afstand < raster.celGrootte && !appel.gegeten) {
      this.leven++;
      appel.gegeten = true;
      appel.x = -100;
      appel.y = -100;
      return true;
    }
    return false;
  }
  
  toon() {
    image(this.animatie[this.frameNummer], this.x, this.y, raster.celGrootte, raster.celGrootte);
  }
}

// Vijand class
class Vijand {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.sprite = null;
    this.stapGrootte = null;
  }

  beweeg() {
    this.x += floor(random(-1, 2)) * this.stapGrootte;
    this.y += floor(random(-1, 2)) * this.stapGrootte;

    this.x = constrain(this.x, 0, canvas.width - raster.celGrootte);
    this.y = constrain(this.y, 0, canvas.height - raster.celGrootte);
  }
  
  toon() {
    image(this.sprite, this.x, this.y, raster.celGrootte, raster.celGrootte);
  }
}

// StilAppel class
class StilAppel {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.gegeten = false;
    this.sprite = appelRoodImg;
  }

  toon() {
    image(this.sprite, this.x, this.y, raster.celGrootte, raster.celGrootte);
  }
}

// StuiterendeAppel class
class StuiterendeAppel {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.gegeten = false;
    this.snelheid = 2;
    this.daling = true;
    this.sprite = appelGroenImg;
  }

  beweeg() {
    if (this.daling) {
      this.x += this.snelheid;
      this.y += this.snelheid;
      if (this.x >= canvas.width - raster.celGrootte || this.y >= canvas.height - raster.celGrootte) {
        this.daling = false;
      }
    } else {
      this.x -= this.snelheid;
      this.y -= this.snelheid;
      if (this.x <= 0 || this.y <= 0) {
        this.daling = true;
      }
    }
  }

  toon() {
    if (!this.gegeten) {
      image(this.sprite, this.x, this.y, raster.celGrootte, raster.celGrootte);
    }
  }
}

// Bom class
class Bom {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.snelheid = random(1, 4);
    this.daling = true;
    this.geraakt = false;
  }

  beweeg() {
    if (this.daling) {
      this.y += this.snelheid;
      if (this.y >= canvas.height - raster.celGrootte) {
        this.daling = false;
      }
    } else {
      this.y -= this.snelheid;
      if (this.y <= 0) {
        this.daling = true;
      }
    }
  }

  toon() {
    if (!this.geraakt) {
      image(bomAfbeelding, this.x, this.y, raster.celGrootte, raster.celGrootte);
    }
  }
}
