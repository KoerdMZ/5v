let bommen = [];
let achtergrondKleur = [255, 255, 255]; // Wit als de achtergrondkleur
let brug;
let appelRoodImg, appelGroenImg, bomAfbeelding;
let raster;
let eve, alice, bob, appelRood, appelGroen;

let oranjeRij = 5; // De rij waarop de oranje kleur staat
let oranjeKolom = 7; // De kolom waarop de oranje kleur staat

function preload() {
  // Afbeeldingen worden ingeladen voordat het spel start
  brug = loadImage("images/backgrounds/dame_op_brug_1800.jpg");
  appelRoodImg = loadImage("images/sprites/Appel/appel_2.png");
  appelGroenImg = loadImage("images/sprites/Appel/appel_1.png");
  bomAfbeelding = loadImage("images/sprites/Bom/bom.png");
}

function setup() {
  // Maak het canvas en stel de framesnelheid in
  canvas = createCanvas(900, 600);
  canvas.parent();
  frameRate(10); // Framesnelheid van 10 per seconde
  textFont("Verdana");
  
  // Maak een raster met 12 rijen en 18 kolommen
  raster = new Raster(12, 18);
  raster.berekenCelGrootte(); // Bereken de grootte van elke cel in het raster
  
  // Maak het speler object (eve) en stel de animatie frames in
  eve = new Jos();
  eve.stapGrootte = 1 * raster.celGrootte;
  for (let b = 0; b < 6; b++) {
    let frameEve = loadImage("images/sprites/Eve100px/Eve_" + b + ".png");
    eve.animatie.push(frameEve); // Voeg animatie frames toe
  }
  
  // Maak vijand objecten (alice, bob)
  alice = new Vijand(700, 200);
  alice.stapGrootte = 1 * eve.stapGrootte;
  alice.sprite = loadImage("images/sprites/Alice100px/Alice.png");

  bob = new Vijand(600, 400);
  bob.stapGrootte = 1 * eve.stapGrootte;
  bob.sprite = loadImage("images/sprites/Bob100px/Bob.png");  

  // Maak appels (rood en groen)
  appelRood = new StilAppel(300, 300);
  appelGroen = new StuiterendeAppel(100, 100);

  // Maak bommen met willekeurige snelheid en locatie
  for (let i = 0; i < 5; i++) {
    let x = floor(random(oranjeKolom + 2, raster.aantalKolommen)) * raster.celGrootte;
    let y = floor(random(oranjeRij + 1, raster.aantalRijen)) * raster.celGrootte;
    let snelheid = random(2, 5); // Verhoogde snelheid voor elk bom
    bommen.push(new Bom(x, y, snelheid)); // Voeg bom toe aan de lijst
  }
}

function draw() {
  // Controleer of de cursor over de oranje cellen is
  if (isCursorOverOrangeCells()) {
    achtergrondKleur = [173, 216, 230]; // Lichte blauwe achtergrond
    background(achtergrondKleur);
  } else {
    background(brug); // Standaard achtergrond
  }

  // Teken het raster met oranje kleur voor de aangegeven rij en kolom
  raster.teken(oranjeRij, oranjeKolom);

  // Beweeg en toon elke bom
  for (let i = bommen.length - 1; i >= 0; i--) {
    let bom = bommen[i];
    bom.beweeg();
    bom.toon();

    // Controleer of de speler de bom raakt
    if (eve.raaktBom(bom) && !bom.geraakt) {
      eve.leven--; // Verminder leven van de speler
      bom.geraakt = true; // Markeer de bom als geraakt
      bommen.splice(i, 1); // Verwijder de bom uit de lijst
    }
  }

  // Beweeg de speler en vijanden
  eve.beweeg();
  alice.beweeg();
  bob.beweeg();
  eve.toon();
  alice.toon();
  bob.toon();

  // Controleer of de speler geraakt wordt door een vijand
  if (eve.wordtGeraakt(alice) || eve.wordtGeraakt(bob)) {
    eve.leven--; // Verminder leven van de speler
    if (eve.leven <= 0) {
      noLoop(); // Stop het spel als het leven op is
    }
  }

  // Toon de appels
  appelRood.toon();
  appelGroen.beweeg();
  appelGroen.toon();

  // Als de speler een appel eet, wordt het leven verhoogd
  if (eve.eetAppel(appelRood)) {}
  if (eve.eetAppel(appelGroen)) {}

  // Controleer of de speler gewonnen heeft
  if (eve.gehaald) {
    background('green');
    fill('white');
    textSize(90);
    textAlign(CENTER, CENTER);
    text("Je hebt gewonnen!", width / 2, height / 2);
    noLoop(); // Stop het spel
  }

  // Controleer of de speler verloren heeft
  if (eve.leven <= 0) {
    background('red');
    fill('white');
    textSize(100);
    textAlign(CENTER, CENTER);
    text("Je hebt verloren!", width / 2, height / 2);
    noLoop(); // Stop het spel
  } else {
    fill('black');
    textSize(20);
    text("Levens: " + eve.leven, 10, 30); // Toon het aantal levens
  }
}

// Controleer of de cursor over de oranje cellen is
function isCursorOverOrangeCells() {
  let x = mouseX;
  let y = mouseY;
  
  let kolomIndex = floor(x / raster.celGrootte);
  let rijIndex = floor(y / raster.celGrootte);
  
  return (rijIndex === oranjeRij || kolomIndex === oranjeKolom); // Controleer de positie
}

// Rasterklasse voor het raster en de tekening
class Raster {
  constructor(r, k) {
    this.aantalRijen = r; // Aantal rijen in het raster
    this.aantalKolommen = k; // Aantal kolommen in het raster
    this.celGrootte = null; // Celgrootte wordt later berekend
  }
  
  // Bereken de grootte van elke cel
  berekenCelGrootte() {
    this.celGrootte = canvas.width / this.aantalKolommen;
  }
  
  // Teken het raster op het canvas
  teken(gekleurdeRij, gekleurdeKolom) {
    push();
    noFill();
    stroke('grey');
    
    for (let rij = 0; rij < this.aantalRijen; rij++) {
      for (let kolom = 0; kolom < this.aantalKolommen; kolom++) {
        if (rij === gekleurdeRij || kolom === gekleurdeKolom) {
          fill('orange');
          noStroke();
        } else {
          noFill();
          stroke('grey');
        }
        rect(kolom * this.celGrootte, rij * this.celGrootte, this.celGrootte, this.celGrootte); // Teken het vakje
      }
    }
    pop();
  }
}

// Bom klasse om bommen te maken die bewegen en getoond worden
class Bom {
  constructor(x, y, snelheid) {
    this.x = x; // X positie van de bom
    this.y = y; // Y positie van de bom
    this.snelheid = snelheid; // Snelheid van de bom
    this.geraakt = false; // Of de bom geraakt is
  }

  beweeg() {
    this.y += this.snelheid; // Beweeg de bom naar beneden
    if (this.y >= canvas.height) {
      this.y = 0; // Als de bom onderaan het scherm is, ga terug naar boven
    }
  }

  toon() {
    if (!this.geraakt) {
      image(bomAfbeelding, this.x, this.y, raster.celGrootte, raster.celGrootte); // Toon de bom
    }
  }
}

// Spelerklasse (Jos) voor het beheren van de speler
class Jos {
  constructor() {
    this.x = 400; // Startpositie X
    this.y = 300; // Startpositie Y
    this.animatie = []; // Lijst van animatiefoto's
    this.frameNummer = 3; // Huidig animatie frame
    this.stapGrootte = null; // Stapgrootte wordt later berekend
    this.gehaald = false; // Of de speler het doel heeft bereikt
    this.leven = 1; // Aantal levens van de speler
  }
  
  // Beweeg de speler op basis van toetsinvoer
  beweeg() {
    if (keyIsDown(65)) { // A key (links)
      this.x -= this.stapGrootte;
      this.frameNummer = 2;
    }
    if (keyIsDown(68)) { // D key (rechts)
      this.x += this.stapGrootte;
      this.frameNummer = 1;
    }
    if (keyIsDown(87)) { // W key (omhoog)
      this.y -= this.stapGrootte;
      this.frameNummer = 4;
    }
    if (keyIsDown(83)) { // S key (omlaag)
      this.y += this.stapGrootte;
      this.frameNummer = 5;
    }
    
    // Beperk de beweging binnen het canvas
    this.x = constrain(this.x, 0, canvas.width);
    this.y = constrain(this.y, 0, canvas.height - raster.celGrootte);
    
    if (this.x >= canvas.width - raster.celGrootte) {
      this.gehaald = true; // Speler heeft het doel bereikt
    }
  }
  
  // Controleer of de speler een vijand raakt
  wordtGeraakt(vijand) {
    return this.x === vijand.x && this.y === vijand.y;
  }

  // Controleer of de speler een bom raakt
  raaktBom(bom) {
    const afstand = dist(this.x, this.y, bom.x, bom.y);
    return afstand < raster.celGrootte;
  }
  
  // Controleer of de speler een appel eet
  eetAppel(appel) {
    const afstand = dist(this.x, this.y, appel.x, appel.y);
    if (afstand < raster.celGrootte && !appel.gegeten) {
      this.leven++; // Verhoog het aantal levens
      appel.gegeten = true; // Markeer appel als gegeten
      appel.x = -100; // Zet de appel buiten het canvas
      appel.y = -100;
      return true;
    }
    return false;
  }
  
  // Toon de speler
  toon() {
    image(this.animatie[this.frameNummer], this.x, this.y, raster.celGrootte, raster.celGrootte);
  }
}

// Vijandklasse om vijanden te beheren
class Vijand {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.sprite = null; // Sprite voor de vijand
    this.stapGrootte = null; // Stapgrootte voor de vijand
  }

  // Beweeg de vijand willekeurig
  beweeg() {
    this.x += floor(random(-1, 2)) * this.stapGrootte;
    this.y += floor(random(-1, 2)) * this.stapGrootte;

    // Beperk de beweging binnen het canvas
    this.x = constrain(this.x, 0, canvas.width - raster.celGrootte);
    this.y = constrain(this.y, 0, canvas.height - raster.celGrootte);
  }
  
  // Toon de vijand
  toon() {
    image(this.sprite, this.x, this.y, raster.celGrootte, raster.celGrootte);
  }
}

// StilAppel klasse voor de stilstaande appel
class StilAppel {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.gegeten = false; // Of de appel gegeten is
  }

  toon() {
    if (!this.gegeten) {
      image(appelRoodImg, this.x, this.y, raster.celGrootte, raster.celGrootte); // Toon de appel
    }
  }
}

// StuiterendeAppel klasse voor de stuiterende appel
class StuiterendeAppel {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.gegeten = false; // Of de appel gegeten is
    this.snelheidX = 2; // Snelheid in X richting
    this.snelheidY = 2; // Snelheid in Y richting
  }

  beweeg() {
    this.x += this.snelheidX; // Beweeg de appel in X richting
    this.y += this.snelheidY; // Beweeg de appel in Y richting
    if (this.x <= 0 || this.x >= width - raster.celGrootte) {
      this.snelheidX *= -1; // Verander richting als de appel de zijkant raakt
    }
    if (this.y <= 0 || this.y >= height - raster.celGrootte) {
      this.snelheidY *= -1; // Verander richting als de appel de boven- of onderkant raakt
    }
  }

  toon() {
    if (!this.gegeten) {
      image(appelGroenImg, this.x, this.y, raster.celGrootte, raster.celGrootte); // Toon de appel
    }
  }
}
