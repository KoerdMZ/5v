class Raster {
  constructor(r, k) {
    this.aantalRijen = r;
    this.aantalKolommen = k;
    this.celGrootte = null;
  }
  
  berekenCelGrootte() {
    this.celGrootte = canvas.width / this.aantalKolommen;
  }
  
  teken() {
    push();
    noFill();
    stroke('grey');
    for (let rij = 0; rij < this.aantalRijen; rij++) {
      for (let kolom = 0; kolom < this.aantalKolommen; kolom++) {
        rect(kolom * this.celGrootte, rij * this.celGrootte, this.celGrootte, this.celGrootte);
      }
    }
    pop();
  }
}

class Jos {
  constructor() {
    this.x = 400;
    this.y = 300;
    this.animatie = [];
    this.frameNummer = 3;
    this.stapGrootte = null;
    this.gehaald = false;
    this.leven = 1;
  }
  
  beweeg() {
    if (keyIsDown(65)) {
      this.x -= this.stapGrootte;
      this.frameNummer = 2;
    }
    if (keyIsDown(68)) {
      this.x += this.stapGrootte;
      this.frameNummer = 1;
    }
    if (keyIsDown(87)) {
      this.y -= this.stapGrootte;
      this.frameNummer = 4;
    }
    if (keyIsDown(83)) {
      this.y += this.stapGrootte;
      this.frameNummer = 5;
    }
    
    this.x = constrain(this.x, 0, canvas.width);
    this.y = constrain(this.y, 0, canvas.height - raster.celGrootte);
    
    if (this.x >= canvas.width) {
      this.gehaald = true;
    }
  }
  
  wordtGeraakt(vijand) {
    return this.x === vijand.x && this.y === vijand.y;
  }

  raaktBom(bom) {
    const afstand = dist(this.x, this.y, bom.x, bom.y);
    return afstand < raster.celGrootte;
  }
  
  eetAppel(appel) {
    const afstand = dist(this.x, this.y, appel.x, appel.y);
    if (afstand < raster.celGrootte && !appel.gegeten) {
      this.leven++;
      appel.gegeten = true;
      appel.x = -100;
      appel.y = -100;
      return true;
    }
    return false;
  }
  
  toon() {
    image(this.animatie[this.frameNummer], this.x, this.y, raster.celGrootte, raster.celGrootte);
  }
}

class Vijand {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.sprite = null;
    this.stapGrootte = null;
  }

  beweeg() {
    this.x += floor(random(-1, 2)) * this.stapGrootte;
    this.y += floor(random(-1, 2)) * this.stapGrootte;

    this.x = constrain(this.x, 0, canvas.width - raster.celGrootte);
    this.y = constrain(this.y, 0, canvas.height - raster.celGrootte);
  }
  
  toon() {
    image(this.sprite, this.x, this.y, raster.celGrootte, raster.celGrootte);
  }
}

class StilAppel {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.gegeten = false;
    this.sprite = appelRoodImg;
  }

  toon() {
    image(this.sprite, this.x, this.y, raster.celGrootte, raster.celGrootte);
  }
}

class StuiterendeAppel {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.gegeten = false;
    this.snelheid = 2;
    this.daling = true;
    this.sprite = appelGroenImg;
  }

  beweeg() {
    if (this.daling) {
      this.x += this.snelheid;
      this.y += this.snelheid;
      if (this.x >= canvas.width - raster.celGrootte || this.y >= canvas.height - raster.celGrootte) {
        this.daling = false;
      }
    } else {
      this.x -= this.snelheid;
      this.y -= this.snelheid;
      if (this.x <= 0 || this.y <= 0) {
        this.daling = true;
      }
    }
  }

  toon() {
    if (!this.gegeten) {
      image(this.sprite, this.x, this.y, raster.celGrootte, raster.celGrootte);
    }
  }
}

class Bom {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.snelheid = random(1, 4); // Geef elke bom een willekeurige snelheid
    this.daling = true;
  }

  beweeg() {
    if (this.daling) {
      this.y += this.snelheid;
      if (this.y >= canvas.height - raster.celGrootte) {
        this.daling = false;
      }
    } else {
      this.y -= this.snelheid;
      if (this.y <= 0) {
        this.daling = true;
      }
    }
  }

  toon() {
    image(bomAfbeelding, this.x, this.y, raster.celGrootte, raster.celGrootte);
  }
}

let bommen = [];

function preload() {
  brug = loadImage("images/backgrounds/dame_op_brug_1800.jpg");
  appelRoodImg = loadImage("images/sprites/Appel/appel_2.png");
  appelGroenImg = loadImage("images/sprites/Appel/appel_1.png");
  bomAfbeelding = loadImage("images/sprites/Bom/bom.png", 
      () => console.log("Bom afbeelding geladen"), 
      () => console.log("Fout bij het laden van de bom afbeelding"));
}

function setup() {
  canvas = createCanvas(900, 600);
  canvas.parent();
  frameRate(10);
  textFont("Verdana");
  textSize(90);
  
  raster = new Raster(12, 18);
  raster.berekenCelGrootte();
  
  eve = new Jos();
  eve.stapGrootte = 1 * raster.celGrootte;
  for (let b = 0; b < 6; b++) {
    let frameEve = loadImage("images/sprites/Eve100px/Eve_" + b + ".png");
    eve.animatie.push(frameEve);
  }
  
  alice = new Vijand(700, 200);
  alice.stapGrootte = 1 * eve.stapGrootte;
  alice.sprite = loadImage("images/sprites/Alice100px/Alice.png");

  bob = new Vijand(600, 400);
  bob.stapGrootte = 1 * eve.stapGrootte;
  bob.sprite = loadImage("images/sprites/Bob100px/Bob.png");  

  appelRood = new StilAppel(300, 300);
  appelGroen = new StuiterendeAppel(100, 100);

  // Maak 5 bommen
  for (let i = 0; i < 5; i++) {
    let x = floor(random(0, raster.aantalKolommen)) * raster.celGrootte;
    let y = floor(random(0, raster.aantalRijen)) * raster.celGrootte;
    bommen.push(new Bom(x, y));
  }
}

function draw() {
  background(brug);
  raster.teken();
  
  for (let bom of bommen) {
    bom.beweeg();
    bom.toon();
    
    // Controleer of Jos de bom raakt
    if (eve.raaktBom(bom)) {
      eve.leven--;
      // Reset de bom naar een nieuwe locatie
      bom.x = floor(random(0, raster.aantalKolommen)) * raster.celGrootte;
      bom.y = floor(random(0, raster.aantalRijen)) * raster.celGrootte;
    }
  }

  eve.beweeg();
  alice.beweeg();
  bob.beweeg();
  eve.toon();
  alice.toon();
  bob.toon();

  // Controleer of Jos geraakt wordt door Alice of Bob
  if (eve.wordtGeraakt(alice) || eve.wordtGeraakt(bob)) {
    eve.leven--;
    if (eve.leven <= 0) {
      noLoop();
    }
  }

  appelRood.toon();
  appelGroen.beweeg();
  appelGroen.toon();

  if (eve.eetAppel(appelRood)) {}

  if (eve.eetAppel(appelGroen)) {}

  if (eve.gehaald) {
    background('green');
    fill('white');
    text("Je hebt gewonnen!", 30, 300);
    noLoop();
  }

  if (eve.leven <= 0) {
    background('red');
    fill('white');
    text("Je hebt verloren!", 30, 300);
    noLoop();
  }

  fill('black');
  textSize(20);
  text("Levens: " + eve.leven, 10, 30);
}

